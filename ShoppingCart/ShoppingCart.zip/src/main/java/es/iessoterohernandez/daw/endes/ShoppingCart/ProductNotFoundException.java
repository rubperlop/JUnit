package es.iessoterohernandez.daw.endes.ShoppingCart;

public class ProductNotFoundException extends Exception {
	public ProductNotFoundException() {
		super();
	}
}
